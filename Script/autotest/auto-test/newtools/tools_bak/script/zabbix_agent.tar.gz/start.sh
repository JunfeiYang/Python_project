#!/bin/bash
ps -ef |grep "zabbix_agentd"|awk '{print $2}'|xargs kill -9
mkdir -p /home/zabbix/zabbix_agent/data
mkdir -p /home/zabbix/zabbix_agent/log
/home/zabbix/zabbix_agent/sbin/zabbix_agentd -c /home/zabbix/zabbix_agent/conf/zabbix_agentd.conf
