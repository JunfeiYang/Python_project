/*
 * Copyright 2010 YoYo Systems, Inc.
 *
 * $ Id:$
 */

/*
 * -----------------------------------------------------------
 * file name  : ManagerType.java
 * creator    : zhangtao(zhang.tao@yoyosys.com)
 * created    : 2012年05月09日 星期三 17时02分48秒
 *
 * modifications:
 *
 * -----------------------------------------------------------
 */
package com.yoyosys.autotest.platform.server;

public enum ManagerType
{
  PROPERTY,
  DB,
}

