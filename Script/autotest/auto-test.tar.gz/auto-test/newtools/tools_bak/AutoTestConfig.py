#!/usr/bin/env python
PROXY_SERVER = "0.0.0.0:8081"
THREAD_POOL_SIZE = 2
LOGFILENAME="./AutoTestProxy.log"
