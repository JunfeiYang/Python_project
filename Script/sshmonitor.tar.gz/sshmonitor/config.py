#!/usr/bin/env python

import os
import sys

class Config(object):
   _instance = None
   _config = {}
   def __new__(cls, *args, **kwargs):  
        if not cls._instance:  
            cls._instance = super(Config, cls).__new__(  
                                cls, *args, **kwargs)  
        return cls._instance

   def load(self,filename):
      f = open(filename, 'r')
      for line in f:
         line=line.strip()
         ps=line.split('=')
         if len(ps) >= 2 :
            self._config[ps[0]]=ps[1]

   def get(self,key):
      return self._config.get(key)

   def getArray(self,key,delim=' '):
      if self._config.get(key) == None or self._config.get(key) == "" or len(self._config[key]) == 0:
         return []
      else:
         return self._config[key].split(delim)
