#!/usr/bin/env python

import os
import sys
import string
import ssh
import config

def check(checkNodes,checkUsers,checkPass, checkPaths,checkKeys):
  conf=config.Config()
   
  nodes=conf.getArray(checkNodes)
  users=conf.getArray(checkUsers)
  pwds=conf.getArray(checkPass)
  paths=conf.getArray(checkPaths)
  ckeys=conf.getArray(checkKeys,'|')

  if len(paths) == 0 :
     return 1,"not set bitsflow setup path"
  if len(users) < len(nodes) :
     return 1,"not enough users"
  if len(pwds) < len(nodes) :
     return 1,"not enough passwords"
  if len(ckeys) < len(nodes) :
     return 1,"not enough check key group"
  error=0
  for n in range(0,len(nodes)):  
     node=nodes[n]
     user=users[n]
     pwd=pwds[n]
     keys=ckeys[n].split(' ')
     if len(paths) >= n :
        pth=paths[n-1]
     else:
        pth=paths[0]
     for keyn in keys:
        kn=keyn.split(':')
        if len(kn) == 1:
           key = kn[0]
           num = 1
        else:
           key = kn[0]
           num = string.atoi(kn[1])

        cmd="ps -ef|grep " + pth + "|grep -v grep|grep " + key + "|awk '{ sum ++ }; END { print sum }'"
        err,out=ssh.executeSshCommand(node,22,user,pwd,cmd)
        cerr=0
        if err != None and err != '':
           print "error:".join(err)
           cerr=1
        out = out.strip()
        if cerr==0 and (out == None or out == ""):
           print "error: not found "+ key +" process in "+node
           cerr=1
        if cerr==0 and string.atoi(out) != num:
           print "error: found "+ out + " " + key +" process in "+node + " , but expect is " + num
           cerr=1
        if cerr == 1:
           error=1
        else:
           print "check " + node + "'s " + key + " process ok"
  if error==1:
     return 1,"Error"
  else:
     return 0,'Ok'
