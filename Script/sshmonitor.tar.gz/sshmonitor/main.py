#!/usr/bin/env python

import os
import sys
import ssh
import config
import check

if __name__ == '__main__':
  conf=config.Config()
  conf.load('config')
  
  code,message=check.check('BITSFLOW_NODE','BITSFLOW_USERS','BITSFLOW_PASSWORDS','BITSFLOW_CHECK_PROCESS_PATH','BITSFLOW_CHECK_KEYS')
  print str(code) + ' ' + message
  code,message=check.check('DATACELL_NODE','DATACELL_USERS','DATACELL_PASSWORDS','DATACELL_CHECK_PROCESS_PATH','DATACELL_CHECK_KEYS')
  print str(code) + ' ' + message
  code,message=check.check('TOMCAT_NODE','TOMCAT_USERS','TOMCAT_PASSWORDS','TOMCAT_CHECK_PROCESS_PATH','TOMCAT_CHECK_KEYS')
  print str(code) + ' ' + message

