#!/usr/bin/env python

import os
import sys
import paramiko

#class ssh(object):
def executeSshCommand(ip,port,username,password,command):
      s=paramiko.SSHClient()
      s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      s.connect(ip,port,username,password)
      stdin,stdout,stderr=s.exec_command(command)
      err=stderr.read()
      out=stdout.read()
      s.close()
      return err,out
